<!DOCTYPE html>
<html>
<head>
    <title>Inquiry</title>
</head>
<body>
<h1>This is a test email sent via Gmail SMTP in Laravel!</h1>
</body>
</html>

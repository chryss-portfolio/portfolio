<h1 class="font-extralight text-2xl text-white">Chryss' Portfolio</h1>
<?php /**PATH C:\Users\user\Herd\portfolio\resources\views/components/application-logo.blade.php ENDPATH**/ ?>